$(function() {
  makeASweetVoronoiTesselation('#voronoi')
})
