const a=[1222,2,3,43,123,54]
const [b]=a
console.log("rdapp - b", b)