new Artitalk({
    appId: 'diTi74ah5rpPDNa6bjS0VjqN-gzGzoHsz', // Your LeanCloud appId
    appKey: 'nHbjOKICQKYQtsVVJjeHYl0O', // Your LeanCloud appKey
    serverURL:'https://diti74ah.lc-cn-n1-shared.com',
    pageSize: 6,
    shuoPla: "小声哔哔..."
})


